<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->add('/', 'Home::index');
$routes->add('home/banpara', 'Home::parc');
$routes->add('home/noticias', 'Home::noti');
$routes->add('home/quem-somos', 'Home::quem');
$routes->add('home/contato', 'Home::cont');
$routes->add('home/orcamento', 'Home::orca');
$routes->add('home/residencial', 'Home::i1');
$routes->add('home/industrial', 'Home::i2');
$routes->add('home/empresarial', 'Home::i3');
$routes->add('home/area-rural', 'Home::i4');
$routes->add('quando-faltar-energia-eletrica-meu-sistema-solar-continuara-funcionando', 'Noticias::n01');
$routes->add('o-sistema-solar-funciona-a-noite', 'Noticias::n02');
$routes->add('e-possivel-gerar-minha-conta-de-energia-com-energia-solar', 'Noticias::n03');
$routes->add('energia-solar-valoriza-o-seu-imovel', 'Noticias::n04');
$routes->add('e-possivel-gerar-enegia-solar-no-inverno', 'Noticias::n05');
$routes->add('por-que-investir-em-energia-solar-hoje', 'Noticias::n06');
$routes->add('modulo-fotovoltaico', 'Noticias::n07');
$routes->add('usina-solar', 'Noticias::n08');
$routes->add('energia-solar-brasil', 'Noticias::n09');





$routes->group("user",function($routes){
    $routes->get('home','UserController::index',['as'=>'user.home']);
    $routes->get('profile','UserController::profile',['as'=>'user.profile']);
    $routes->get('countries','UserController::countries',['as'=>'countries']);
    $routes->post('addCountry','UserController::addCountry',['as'=>'add.country']);
    $routes->get('getAllCountries','UserController::getAllCountries',['as'=>'get.all.countries']);
    $routes->post('getCountryInfo','UserController::getCountryInfo',['as'=>'get.country.info']);
    $routes->post('updateCountry','UserController::updateCountry',['as'=>'update.country']);
    $routes->post('deleteCountry','UserController::deleteCountry',['as'=>'delete.country']);
});
/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
