<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class ForceHttps implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
       // if (! $request->isSecure()) {
        // force_https();
      //  }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        //if (! $request->isSecure()) {
             //force_https();
       //   }
    }
}