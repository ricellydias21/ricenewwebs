<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function __construct()
    {
        helper(['url', 'form']);
    }
   public function index()
    {
        
        //echo view('pastasolar/solar');
    }
   public function parc()
    {
        echo view('pastasolar/bpa/codigos');
    }
   public function quem()
    {
        echo view('pastasolar/quemsomos/quemsomos');
    }
   public function noti()
    {
        echo view('pastasolar/noticias/noticias');
    }
    public function cont()
    {
        echo view('pastasolar/contato/homecontato');
    }
    public function orca()
    {
        echo view('pastasolar/orcamento/homeorcamento');
    }
    public function i1()
    {
        echo view('pastasolar/energiasolar/residencial');
    }
    public function i2()
    {
        echo view('pastasolar/energiasolar/industrial');
    }
    public function i3()
    {
        echo view('pastasolar/energiasolar/empresarial');
    }
    public function i4()
    {
        echo view('pastasolar/energiasolar/arearural');
    }
}
