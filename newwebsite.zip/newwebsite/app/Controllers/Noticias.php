<?php

namespace App\Controllers;

class Noticias extends BaseController
{
    
    public function n01()
    {
        echo view('pastasolar/noticias/n01');
    }
    
    public function n02()
    {
        echo view('pastasolar/noticias/n02');
    }
    public function n03()
    {
        echo view('pastasolar/noticias/n03');
    }
    public function n04()
    {
        echo view('pastasolar/noticias/n04');
    }
    public function n05()
    {
        echo view('pastasolar/noticias/n05');
    }
    public function n06()
    {
        echo view('pastasolar/noticias/n06');
    }
    public function n07()
    {
        echo view('pastasolar/noticias/n07');
    }
    public function n08()
    {
        echo view('pastasolar/noticias/n08');
    }
    public function n09()
    {
        echo view('pastasolar/noticias/n09');
    }


}
