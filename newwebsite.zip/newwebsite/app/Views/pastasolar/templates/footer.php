<footer class="footer mt-auto py-3 bg-light">
         <div class="container">
            <span class="text-muted">© 2020 solar365. Todos os Direitos Reservados.</span>
            <div class="socials icons-only white color_hover">
               <a target="_blank" title="Facebook" href="https://www.facebook.com/Solar365" class="a13_soc-facebook fa fa-facebook" rel="noopener"></a>
               <a target="_blank" title="Instagram" href="https://www.instagram.com/solar.365/" class="a13_soc-instagram fa fa-instagram" rel="noopener"></a>
            </div>
         </div>
      </footer>
 <script src="<?= base_url() ?>/assets/dist/js/bootstrap.bundle.min.js"></script>
 <script src="<?= base_url() ?>/js/cheatsheet.js"></script>
   </body>
</html>