<!doctype html>
<html lang="pt-br">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
      <title>Home - Solar365</title>
      <link rel="canonical" href="<?= base_url() ?>">
      <meta property="og:locale" content="pt_BR">
      <meta property="og:type" content="website">
      <meta property="og:title" content="Home - Solar365">
      <meta property="og:description" content="ENERGIA SEM LIMITE! Solar365 Esteja do Lado de DE QUEM…  Leia mais">
      <meta property="og:url" content="<?= base_url() ?>">
      <meta property="og:site_name" content="Solar365">
      <meta property="og:image" content="<?= base_url() ?>/solar365/icon_solar365_120x69.png">
      <meta property="og:image:width" content="120">
      <meta property="og:image:height" content="69">
      <link href="<?= base_url() ?>/assets/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
         body, html{
         margin: 0;
         }
         .bd-placeholder-img {
         font-size: 1.125rem;
         text-anchor: middle;
         -webkit-user-select: none;
         -moz-user-select: none;
         user-select: none;
         }
         @media (min-width: 768px) {
         .bd-placeholder-img-lg {
         font-size: 3.5rem;
         }
         }
         .solar365-Center{
         background-color: #0B364E;
         background-position: center center;
         background-repeat: no-repeat;
         background-size: cover;
         }
         .a13ree-written-headline {
         text-align: center;
         color: #ffffff;
         font-family: "Roboto", Sans-serif;
         font-size: 55px;
         font-weight: 600;
         line-height: 1.1em;
         }
         .real-content h2 {
         font-size: 2em;
         line-height: 1.1;
         }
         .written-lines{
         color: #FFA600;
         font-family: "Roboto", Sans-serif;
         font-weight: 300;
         line-height: 1.1em;
         }
         .p-solar365-branco{
         color: #ffffff;
         }
         .elementor-element-6e3190b {
         background: #FFA600;
         width: 70px;
         height: 5px;
         }
         .solar365-bor{
         border-style: solid;
         border-width: 2px 2px 2px 2px;
         border-color: #FFA600;
         transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;
         border-radius: 10px 10px 10px 10px;
         }
         .p-solar365-fonte-border{
         color: #FFA600;
         font-family: "Roboto", Sans-serif;
         font-size: 18px;
         font-weight: 600;
         line-height: 1.2em;
         }
         .background-overlay {
         background-color: transparent;
         background-image: linear-gradient(0deg, rgba(11, 54, 78, 0.29) 0%, #0B364E 100%);
         opacity: 1;
         transition: background 0.3s, border-radius 0.3s, opacity 0.3s;
         }
		.background-overlay2 {
		background-color: transparent;
		background-image: linear-gradient(180deg, #0B364E 0%, #0B364E9C 100%);
		opacity: 1;
		transition: background 0.3s, border-radius 0.3s, opacity 0.3s;
		}
      </style>
   </head>
   <body>
   <?= $this->renderSection('content') ?>
   <?= $this->include('pastasolar/contato/contato') ?>
   <?= $this->include('pastasolar/templates/footer') ?>