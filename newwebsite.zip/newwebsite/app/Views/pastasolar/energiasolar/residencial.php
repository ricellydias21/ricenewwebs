<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
                <p>A energia solar está em alta nas últimas décadas e, apesar das grandes usinas solares fotovoltaicas estarem sempre aparecendo nas mídias, o que mais vem crescendo em número são os projetos de energia solar residencial conectados à rede para geração distribuída.</p><p>Esses projetos de energia solar, geralmente instalados nos telhados das casas, são os pequenos geradores de energia elétrica que funcionam movidos por energia solar e que permitem ao consumidor residencial gerar toda, ou uma parte, da energia elétrica consumida em seu imóvel.</p><p>Com a energia produzida através de um desses geradores, o consumidor residencial consegue economizar até 95% em sua conta de luz, resultado do sistema de compensação de energia elétrica vigente dentro do segmento distribuído e motivo pelo o qual esses geradores se espalham pelo país.</p>                    

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

                Quer saber quanto você pode economizar produzindo sua própria energia?                    

                <span style="color: #ffa600;">MAIS SOBRE</span> ENERGIA SOLAR RESIDENCIAL                    

                <p><span style="color: #ffa600;">NOTÍCIAS SOBRE</span> ENERGIA SOLAR </p>                    

                <h3 class="elementor-icon-box-title">
                    <span>
                        1- SIMULE SEU SISTEMA SOLAR                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Avaliação e análise de viabilidade técnica e financeira e do potencial de economia com o seu futuro sistema solar. Simule aqui seu sistema.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        2- ELABORANDO SUA PROPOSTA                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Após simular seu sistema você pede um orçamento personalizado para a sua casa e receberá um atendimento do nosso especialista solar mais próximo de você.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        3- NEGÓCIO FECHADO                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com a proposta em mãos, e todos os passos descritos de forma transparente e clara, você irá fechar a solução completa, sem custos extras e com equipamentos e serviços de altíssima qualidade.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        4- DOCUMENTAÇÃO DE ACESSO A REDE                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com experiência de mais de 2.100 sistemas vendidos e instalados por todo o Brasil, a Blue Sol já realizou conexões em mais de 30 distribuidoras. Iremos conduzir todos os processos de conexão para que seu futuro sistema solar seja entregue sem atrasos.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        5- INSTALAÇÃO DO SEU SISTEMA SOLAR                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com equipe treinada, identificada, e preparada com todos os equipamentos de segurança, a instalação em sua propriedade será uma experiência tranquila e com garantia de qualidade.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        6- ATIVAÇÃO NA DISTRIBUIDORA                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        O último passo é a distribuidora de energia local vir trocar o seu medidor de energia, para que você comece a contabilizar seus créditos energéticos solares. A partir daqui, você começa a poupar pelos próximos 30 anos.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        7- DINHEIRO NO BOLSO                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Na sua primeira conta após a conexão do seu sistema o dinheiro que iria para a distribuidora e energia local fica no seu bolso e você finalmente está livre dessa conta.                    </p>
                        </div>
    </div>
 </section>
</main>
                        <?= $this->endSection() ?>