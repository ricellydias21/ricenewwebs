<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
<p><strong>A REDUÇÃO DOS GASTOS COM AQUISIÇÃO</strong></p><p>Devido à demanda crescente pelos painéis solares, os custos de aquisição do sistema vêm caindo progressivamente. Assim, usar energia solar como fonte alternativa para a energia elétrica é uma boa opção para as pequenas e médias empresas.</p><p>Como se trata de um investimento em longo prazo, muito bancos e outras instituições financeiras recebem incentivos do governo para realizar</p><p>financiamentos especiais para as pequenas empresas que desejam instalar sistemas de energia solar.</p><p><strong>A REDUÇÃO DOS CUSTOS COM TRIBUTAÇÃO</strong></p><p>A energia elétrica do Brasil é uma das mais caras do mundo. Conforme a ANEEL (Agência Nacional de Energia Elétrica), os tributos que envolvem o setor podem alcançar um percentual de 56% do valor total da conta de luz.</p><p>Empresas menores tendem a sofrer mais com o reajuste das tarifas e não podem abrir mão desse recurso (energia elétrica), fundamental para qualquer ciclo de produção e vendas.</p><p>A energia solar para empresas é uma solução que permite à organização contar com sua própria fonte de eletricidade, não ficando tão dependente do serviço público e, consequentemente, pagando contas mais baixas no final de cada mês e ganhando mais competitividade.</p><p><strong>A ESTABILIDADE DO FLUXO DE CAIXA</strong></p><p>Uma empresa com um sistema de energia solar conta com proteção e estabilidade, que são dois importantes critérios para a sobrevivência e o sucesso do negócio.</p><p>A PME (pequena e média empresa) fica protegida contra as oscilações nas tarifas de energia elétrica, as quais só contribuem para aumentar as despesas durante o ano e tornar o controle do fluxo de caixa mais difícil.</p><p>Usufruindo de um sistema particular que converte energia solar em energia elétrica, a empresa obtém um fluxo de caixa estável, com a previsibilidade de quanto será gasto mensalmente com as contas de luz — para isso, basta comparar a potência do sistema de energia solar com a média de consumo mensal.</p><p>No caso de o sistema ser capaz de suprir toda a necessidade de consumo do negócio, os custos mensais da conta de luz serão limitados às taxas fixas da distribuidora da cidade (tarifa de iluminação pública, por exemplo).</p><p><strong>A MANUTENÇÃO DE BAIXO CUSTO</strong></p><p>Depois que o sistema for instalado por uma equipe especializada, serão necessárias manutenções periódicas para garantir a durabilidade e o bom desempenho dos painéis.</p><p>Dentre os gastos com um sistema de energia solar para empresas pequenas, a manutenção é um dos mais baixos. Consiste em procedimentos simples e baratos que podem ser efetuados até por um</p><p>funcionário: semestralmente, é necessário limpar os painéis com água corrente para evitar o acumulo de folhas e sujeira.</p><p><strong>ROI &#8211; RETORNO SOBRE INVESTIMENTO</strong></p><p>Vale a pena dedicar um tópico para falar apenas do ROI, o Retorno sobre o Investimento, pois esse índice é de fundamental importância para PMEs.</p><p>Os gastos iniciais de um sistema fotovoltaico parecerão muito altos sob uma primeira análise. Porém, quando se calcula o ROI com cuidado e exatidão, percebe-se que a energia alternativa contribui para uma considerável diminuição nas despesas do negócio.</p><p>Falando na linguagem dos investimentos, a energia solar pode oferecer uma rentabilidade seis vezes maior que a oferecida pela Caderneta de Poupança!</p><p>Portanto, pense na possibilidade de adquirir um sistema de energia solar para empresas e, além de reduzir seus custos com as contas de luz, transformar seu negócio em um exemplo de economia sustentável!</p>                    

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

Quer saber quanto você pode economizar produzindo sua própria energia?                    

<span style="color: #ffa600;">MAIS SOBRE</span> ENERGIA SOLAR RESIDENCIAL                    

<p><span style="color: #ffa600;">NOTÍCIAS SOBRE</span> ENERGIA SOLAR </p>                    

<h3 class="elementor-icon-box-title">
    <span>
        1- SIMULE SEU SISTEMA SOLAR                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Avaliação e análise de viabilidade técnica e financeira e do potencial de economia com o seu futuro sistema solar. Simule aqui seu sistema.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        2- ELABORANDO SUA PROPOSTA                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Após simular seu sistema você pede um orçamento personalizado para a sua casa e receberá um atendimento do nosso especialista solar mais próximo de você.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        3- NEGÓCIO FECHADO                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Com a proposta em mãos, e todos os passos descritos de forma transparente e clara, você irá fechar a solução completa, sem custos extras e com equipamentos e serviços de altíssima qualidade.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        4- DOCUMENTAÇÃO DE ACESSO A REDE                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Com experiência de mais de 2.100 sistemas vendidos e instalados por todo o Brasil, a Blue Sol já realizou conexões em mais de 30 distribuidoras. Iremos conduzir todos os processos de conexão para que seu futuro sistema solar seja entregue sem atrasos.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        5- INSTALAÇÃO DO SEU SISTEMA SOLAR                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Com equipe treinada, identificada, e preparada com todos os equipamentos de segurança, a instalação em sua propriedade será uma experiência tranquila e com garantia de qualidade.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        6- ATIVAÇÃO NA DISTRIBUIDORA                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        O último passo é a distribuidora de energia local vir trocar o seu medidor de energia, para que você comece a contabilizar seus créditos energéticos solares. A partir daqui, você começa a poupar pelos próximos 30 anos.                    </p>
            

<h3 class="elementor-icon-box-title">
    <span>
        7- DINHEIRO NO BOLSO                    </span>
</h3>
                    <p class="elementor-icon-box-description">
        Na sua primeira conta após a conexão do seu sistema o dinheiro que iria para a distribuidora e energia local fica no seu bolso e você finalmente está livre dessa conta.                    </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>