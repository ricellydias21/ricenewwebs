<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
<p>Em tempos de crise energética e aumento de até 60% nas tarifas da conta de luz, a adoção de energia solar em empresas tem sido cada vez buscada. Além do impacto econômico, essas corporações também buscam, com a instalação de painéis fotovoltaicos, provocar melhorias sociais e ambientais no espaço de trabalho, que melhorem a imagem e o valor da empresa.</p><p>Esta alternativa tem sido adotada também por muitas empresas de pequeno e médio porte, que se beneficiam do aumento dos incentivos governamentais de crédito para a adoção de tecnologias sustentáveis de geração de energia. Quer conhecer as vantagens da implantação de energia solar em empresas? Acompanhe nosso artigo e fique informado sobre esta tendência.</p><p>Um dos principais impactos positivos da adoção de energia solar em sua empresa diz respeito à sustentabilidade e preservação do meio ambiente. O sol é uma fonte renovável e inesgotável de energia, e a conversão da solar para a elétrica não emite gases que provocam o efeito estufa. Além</p><p>de ser bom para o planeta, inseri-la na política de sustentabilidade de sua empresa gera valor perante a sociedade e promove a redução dos custos fixos A instalação de painéis fotovoltaicos e geração de energia solar podem melhorar, e muito, a imagem do seu negócio. Se apresentar como uma corporação empenhada em diminuir o impacto gerado por suas atividades, se preocupando com o bem-estar de seus funcionários, clientes e parceiros, pode consolidar e alavancar sua empresa, seja qual for o seu mercado de atuação.</p><p>Obviamente, toda a empresa busca a redução de seus custos fixos. Apesar de ter um investimento inicial considerado alto, a instalação de painéis de captação de energia solar são um ótimo investimento a longo prazo.</p><p>Primeiramente, a conta de energia elétrica diminui drasticamente, ou pode até mesmo zerar, dependendo do tipo de instalação e das condições do local. Isso faz com que o investimento inicial se pague entre 6 e 12 anos, em média. A partir desse período, toda a energia gerada se converte em economia para a empresa. Além disso, a vida útil das placas é muito grande, podendo chegar a 25 anos, o que reduz muito as despesas de manutenção.</p>                    

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. </p>                    

                Quer saber quanto você pode economizar produzindo sua própria energia?                    

                <span style="color: #ffa600;">MAIS SOBRE</span> ENERGIA SOLAR RESIDENCIAL                    

                <p><span style="color: #ffa600;">NOTÍCIAS SOBRE</span> ENERGIA SOLAR</p>                    

                <h3 class="elementor-icon-box-title">
                    <span>
                        1- SIMULE SEU SISTEMA SOLAR                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Avaliação e análise de viabilidade técnica e financeira e do potencial de economia com o seu futuro sistema solar. Simule aqui seu sistema.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        2- ELABORANDO SUA PROPOSTA                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Após simular seu sistema você pede um orçamento personalizado para a sua casa e receberá um atendimento do nosso especialista solar mais próximo de você.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        3- NEGÓCIO FECHADO                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com a proposta em mãos, e todos os passos descritos de forma transparente e clara, você irá fechar a solução completa, sem custos extras e com equipamentos e serviços de altíssima qualidade.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        4- DOCUMENTAÇÃO DE ACESSO A REDE                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com experiência de mais de 2.100 sistemas vendidos e instalados por todo o Brasil, a Blue Sol já realizou conexões em mais de 30 distribuidoras. Iremos conduzir todos os processos de conexão para que seu futuro sistema solar seja entregue sem atrasos.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        5- INSTALAÇÃO DO SEU SISTEMA SOLAR                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Com equipe treinada, identificada, e preparada com todos os equipamentos de segurança, a instalação em sua propriedade será uma experiência tranquila e com garantia de qualidade.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        6- ATIVAÇÃO NA DISTRIBUIDORA                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        O último passo é a distribuidora de energia local vir trocar o seu medidor de energia, para que você comece a contabilizar seus créditos energéticos solares. A partir daqui, você começa a poupar pelos próximos 30 anos.                    </p>
                            

                <h3 class="elementor-icon-box-title">
                    <span>
                        7- DINHEIRO NO BOLSO                    </span>
                </h3>
                                    <p class="elementor-icon-box-description">
                        Na sua primeira conta após a conexão do seu sistema o dinheiro que iria para a distribuidora e energia local fica no seu bolso e você finalmente está livre dessa conta.                    </p>
                        </div>
    </div>
 </section>
</main>
                        <?= $this->endSection() ?>