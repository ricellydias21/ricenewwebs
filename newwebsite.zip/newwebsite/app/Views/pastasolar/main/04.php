<div class="album py-5" style="background-color: #0F4860;">
      <div class="container">
         <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
            <h1 class="display-4 fw-normal p-solar365-branco">Como funciona a energia solar.</h1>
         </div>
         <div class="row">
            <div class="col-lg-4">
               <h2 class="p-solar365-branco">DE MANHÃ</h2>
               <p class="p-solar365-branco">Seu sistema começa a funcionar logo pela manhã, gerando assim energia elétrica de acordo com a intensidade da luz.</p>
            </div>
            <div class="col-lg-4">
               <h2 class="p-solar365-branco">DURANTE O DIA</h2>
               <p class="p-solar365-branco">Você esta gerando boa parte do seu consumo e pode até gerar um excedente, criando assim créditos energéticos para consumir depois.</p>
            </div>
            <div class="col-lg-4">
               <h2 class="p-solar365-branco">À NOITE</h2>
               <p class="p-solar365-branco">Caso tenha gerado créditos durante o dia, você os consome à noite possibilitando até zerar seu consumo de energia total.</p>
            </div>
         </div>
         <div class="pricing-header p-3 mx-auto text-center col-sm-6 solar365-bor">
            <h1 class="display-4 fw-normal p-solar365-fonte-border" style="border-radius: 10px 10px 10px 10px;">VOCÊ NÃO PRECISA DE BATERIA PARA ARMAZENAR ENERGIA, O PRÓPRIO RELÓGIO DA CONCESSIONÁRIA CONTABILIZA TODOS SEUS CRÉDITOS.</h1>
         </div>
         <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
            <h1 class="display-4 fw-normal p-solar365-branco">Mas afinal, o que é ENERGIA SOLAR FOTOVOLTAICA?</h1>
            <br>
            <a class="btn btn-warning btn-outline  btn-lg" href="#">CLIQUE AQUI PARA SABER</a>
         </div>
      </div>
</div>