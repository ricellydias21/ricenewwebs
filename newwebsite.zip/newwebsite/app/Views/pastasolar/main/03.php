<div class="container px-4 py-5" id="custom-cards">
            <div class="row row-cols-1 row-cols-lg-4 align-items-stretch g-4 py-5">
               <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white rounded-5 shadow-lg" style="background-color: #0B364E;">
                     <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                        <span class="elementor-icon elementor-animation-">
                        <i aria-hidden="true" class="fas fa-home"></i>
                        </span>
                        <h3 class="p-solar365-branco">ENERGIA SOLAR RESIDENCIAL</h3>
                        <p class="p-solar365-branco">Reduza os custos de energia elétrica em até 95%. Sua residência com energia ilimitada dia e noite...</p>
                     </div>
                     <p class="text-center"><a class="btn btn-secondary text-center" href="#">SAIBA MAIS</a></p>
                  </div>
               </div>
               <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white rounded-5 shadow-lg" style="background-color: #0B364E;">
                     <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                        <span class="elementor-icon elementor-animation-">
                        <i aria-hidden="true" class="fas fa-building"></i>
                        </span>
                        <h3 class="p-solar365-branco">ENERGIA SOLAR EMPRESARIAL</h3>
                        <p class="p-solar365-branco">Aumente seus lucros, diminuindo os seus custos com energia elétrica em até 95%. Sua empresa com redução...</p>
                     </div>
                     <p class="text-center"><a class="btn btn-secondary text-center" href="#">SAIBA MAIS</a></p>
                  </div>
               </div>
               <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white rounded-5 shadow-lg" style="background-color: #0B364E;">
                     <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                        <span class="elementor-icon elementor-animation-">
                        <i aria-hidden="true" class="fas fa-industry"></i>
                        </span>
                        <h3 class="p-solar365-branco">ENERGIA SOLAR INDUSTRIAL</h3>
                        <p class="p-solar365-branco">Potencialize sua capacidade produção, ganhando diferenciação no mercado e incentivos fiscais e bancários..</p>
                     </div>
                     <p class="text-center"><a class="btn btn-secondary text-center" href="#">SAIBA MAIS</a></p>
                  </div>
               </div>
               <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white rounded-5 shadow-lg" style="background-color: #0B364E;">
                     <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
                        <span class="elementor-icon elementor-animation-">
                        <i aria-hidden="true" class="fas fa-tractor"></i>
                        </span>
                        <h3 class="p-solar365-branco">ENERGIA SOLAR ÁREA RURAL</h3>
                        <p class="p-solar365-branco">Se tem uma solução ideal para cortar os gastos com energia elétrica nas suas propriedades...</p>
                     </div>
                     <p class="text-center"><a class="btn btn-secondary text-center" href="#">SAIBA MAIS</a></p>
                  </div>
               </div>
            </div>
         </div>