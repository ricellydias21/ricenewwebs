<nav class="container-fluid nav nav-underline solar365-Center" style="background-image: url(<?= base_url() ?>/solar365/img_topo_home.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="before-written">ENERGIA<br></span>
               <span class="written-lines">SEM LIMITE!</span>
            </h2>
         </div>
      </div>
   </section>
</nav>