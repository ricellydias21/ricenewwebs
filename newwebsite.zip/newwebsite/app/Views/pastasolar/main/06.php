<main>
   <section class="py-5 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-6 col-md-8 mx-auto">
            <p class="lead text-muted">Estamos num momento de futuras transformações no mundo, e a Solar365 veio para inovar no processo sistemático da tecnologia solar com seu DNA inovador e tecnológico, voltada para geração de energias renováveis através de sistemas fotovoltaicos, atuando nas áreas: residencial, comercial, industrial e rural. Seus benefícios incluem a redução considerável do gasto na conta de luz, por ser tratar de um tipo de energia renovável, que permite que a redução na conta de energia chegue até 95%. Nosso comprometimento é fazer com que as empresas olhem de forma inovadora para o futuro, oferecendo soluções de altas tecnologias, adaptando nossos serviços para que sejamos capazes de responder rapidamente ao mercado em movimento, sendo assim, benéfico socialmente. Nossa ambição por continuar crescendo, fará com que moldemos o futuro da energia, construindo um mundo onde a energia solar seja a principal base para a sustentabilidade das próximas gerações.
               A Solar365 é uma empresa integradora do Grupo WEG, multinacional brasileira, com 60 anos de história, presente em 12 países e reconhecida como uma das maiores fabricantes de equipamentos eletrônicos do mundo, equipamentos para geração e transmissão de energia, automação industrial e eficiência energética.
               Movidos por tecnologia e desafios, nós da Solar365 estamos sempre em busca de soluções inovadoras e de alta performance. Projetos personalizados para a necessidade de cada cliente, é a nossa marca. O nosso compromisso é com a qualidade.
            </p>
         </div>
      </div>
      <div class="album py-5">
         <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
               <div class="col">
                  <div class="card shadow-sm">
                     <img src="<?= base_url() ?>/solar365/img_fabiocastro.jpg" width="400" height="400" alt=""/>
                     <div class="card-body">
                        <h5 class="card-title">SAID HABER</h5>
                        <p class="card-text">Administrador de empresas desde 1998, com MBA em gestão de pessoas. Diretor Financeiro da Solar 365</p>
                     </div>
                  </div>
               </div>
               <div class="col">
                  <div class="card shadow-sm">
                     <img src="<?= base_url() ?>/solar365/img_yele_donato.jpg" width="400" height="400" alt=""/>
                     <div class="card-body">
                        <h5 class="card-title">YELE DONATO</h5>
                        <p class="card-text">Esposo, pai e Empresário, com vasta experiência em marketing e implantações de projetos empresariais. Mais de 15 anos de atuando na gestão de negócios de vendas complexas. Yele Donato é responsável pelo nosso setor comercial, onde está sempre em campo com nossa equipe de consultores atendendo aos nossos clientes e buscando sempre a melhor solução em energia fotovoltaica, do residencial ao agronegócio.</p>
                     </div>
                  </div>
               </div>
               <div class="col">
                  <div class="card shadow-sm">
                     <img src="<?= base_url() ?>/solar365/img_saidhaber.jpg" width="400" height="400" alt=""/>
                     <div class="card-body">
                        <h5 class="card-title">SAID HABER</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas erat tellus, tempus at feugiat id, efficitur nec mi. Donec purus ex, fringilla nec massa eget, dapibus condimentum dolor. Maecenas ac risus ac leo feugiat malesuada luctus eget ante. Mauris eget tortor convallis, sodales ante id, finibus urna. Lorem ipsum dolor sit amet.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section id="components">
         <article class="my-3" id="accordion">
            <div>
               <div class="bd-example">
                  <div class="accordion" id="accordionExample">
                     <div class="accordion-item">
                        <h4 class="accordion-header" id="headingOne">
                           <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                           Missão
                           </button>
                        </h4>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
                           <div class="accordion-body">
                              Desenvolver soluções sob medida, que permitam a nossos clientes o acesso às energias renováveis, primando pela excelência técnica-financeira e respeito ao meio ambiente. Investindo na formação de uma consciência no uso de energia solar fotovoltaica, oferecendo ao mercado produtos e serviços diferenciados com soluções completas e de qualidade, através da oferta tecnologias e equipamentos de ponta, gerando assim valor e vantagens para nossos clientes.
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h4 class="accordion-header" id="headingTwo">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                           Visão
                           </button>
                        </h4>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              Tornar-se empresa de referência, na região amazônica, em projetos de geração distribuída de energia, a partir de fontes renováveis.
                           </div>
                        </div>
                     </div>
                     <div class="accordion-item">
                        <h4 class="accordion-header" id="headingThree">
                           <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                           Valores
                           </button>
                        </h4>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                           <div class="accordion-body">
                              Tecnologia
                              Sustentabilidade
                              Solução
                              Economia
                              Eficiência
                              Respeito
                              Confiança
                              Inovação
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </article>
      </section>
   </section>
</main>