<div class="album py-5 bg-light">
      <div class="container">
         <h2 class="featurette-heading">NOTÍCIAS SOBRE <span style="color: #ffa600;">ENERGIA SOLAR&nbsp;</span></h2>
         <div class="elementor-element-6e3190b"></div>
         <br>
         <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <br>
            <div class="col">
               <div class="card shadow-sm">
                  <img src="<?= base_url() ?>/solar365/falta-de-energia-72wxkxlpte7vqc6ryietom93uz6zn95m8e.jpg" width="100%" height="100%" alt=""/>
                  <div class="card-body">
                     <h5 class="card-title">Quando faltar energia elétrica, meu sistema solar continuará funcionando?</h5>
                     <p class="card-text">Para facilitar, vamos começar pelo princípio de funcionamento do sistema…</p>
                  </div>
               </div>
            </div>
            <div class="col">
               <div class="card shadow-sm">
                  <img src="<?= base_url() ?>/solar365/energia_solar_durante_inverno-729p5vg83fuzw9j242on17v8uqhomzybcq.jpg" width="100%" height="100%" alt=""/>
                  <div class="card-body">
                     <h5 class="card-title">É POSSÍVEL GERAR ENEGIA SOLAR NO INVERNO?</h5>
                     <p class="card-text">Uma das maiores dúvidas sobre o funcionamento da tecnologia fotovoltaica…</p>
                  </div>
               </div>
            </div>
            <div class="col">
               <div class="card shadow-sm">
                  <img src="<?= base_url() ?>/solar365/porque_investir_em_energia_solar-71yx3upqsqrlglguuwjbq9ljvk002zysya.jpg" width="100%" height="100%" alt=""/>
                  <div class="card-body">
                     <h5 class="card-title">Por Que Investir em Energia Solar Hoje?</h5>
                     <p class="card-text">Mesmo com a queda das vendas durante os primeiros meses…</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
</div>