<nav class="navbar navbar-expand-lg navbar-light bg-light rounded background-overlay" aria-label="Twelfth navbar example"> 
   <div class="container-fluid">
      <a href="/" class="navbar-brand d-flex align-items-center">
      <img src="../solar365/logotipo_solar365_307x76.png" alt="Solar365" width="307" height="76"/>
      </a>
      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample10">
         <ul class="navbar-nav">
            <li class="nav-item">
               <a class="nav-link active" aria-current="/" href="#">Home</a>
            </li>
            <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="dropdown10" data-bs-toggle="dropdown" aria-expanded="false">Institucional</a>
               <ul class="dropdown-menu" aria-labelledby="dropdown10">
                  <li><a class="dropdown-item" href="<?= base_url() ?>/home/quem-somos">Quem Somos</a></li>
               </ul>
            </li>
            <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="dropdown11" data-bs-toggle="dropdown" aria-expanded="false">Energia Solar</a>
               <ul class="dropdown-menu" aria-labelledby="dropdown11">
                  <li><a class="dropdown-item" href="<?= base_url() ?>/home/residencial">Residencial</a></li>
                  <li><a class="dropdown-item" href="<?= base_url() ?>/home/empresarial">Empresarial</a></li>
                  <li><a class="dropdown-item" href="<?= base_url() ?>/home/industrial">Industrial</a></li>
                  <li><a class="dropdown-item" href="<?= base_url() ?>/home/area-rural">Área Rural</a></li>
               </ul>
            </li>
            <li class="nav-item">
               <a class="nav-link active" aria-current="page" href="<?= base_url() ?>/home/noticias">Notícias</a>
            </li>
            <li class="nav-item">
               <a class="nav-link active" aria-current="page" href="<?= base_url() ?>/home/contato">Contatos</a>
            </li>
            <li class="nav-item">
               <a class="nav-link active" aria-current="page" href="<?= base_url() ?>/home/orcamento">Orçamento</a>
            </li>
         </ul>
      </div>
   </div>
</nav>