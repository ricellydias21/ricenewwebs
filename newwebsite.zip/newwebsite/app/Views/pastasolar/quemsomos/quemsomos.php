<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<?= $this->include('pastasolar/quemsomos/02') ?>
<?= $this->include('pastasolar/main/06') ?>
<?= $this->endSection() ?>