<main>
  <div class="px-2 py-1 my-2 text-center"><img src="<?= base_url() ?>/solar365/logo_banparaesolar365.png" width="405" height="65" alt=""/></div>

  <div class="b-example-divider"></div>

  <div class="px-4 pt-5 my-0 text-center border-bottom effects-layer" style="padding: 200px 0px 20px 0px;transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;position: relative;">
		<h1 class="display-4 fw-bold">O seu objetivo é economizar? Seja Solar!</h1>
		<div class="col-lg-6 mx-auto">
		  <p class="lead mb-4">Consciente de sua responsabilidade com o desenvolvimento social e a preservação do Meio Ambiente em prol de um futuro mais autossustentável para você e suas futuras gerações, por isso o Banpará uniu forças e expertises com a empresa Solar365 para viabilizar o acesso à energia limpa, renovável e acessível através de uma linha de financiamento exclusiva para Energia Solar! Adquirir um Sistema Solar é investir em sustentabilidade e pode significar uma economia de até 95% na conta de energia elétrica!</p>
		  <div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
			<a href="<?= base_url() ?>/home/orcamento" class="btn btn-primary btn-lg px-5 me-sm-6">FAÇA SUA SIMULAÇÃO E SOLICITE UM ORÇAMENTO</a>
		  </div>
		</div>
		<div class="overflow-hidden" style="max-height: 30vh;">
		  <div class="container px-5"></div>
		</div>
  </div>

  <div class="b-example-divider"></div>
	
  <div class="px-4 pt-5 my-5 bg-secondary text-center">
	  <div class="container col-xxl-10 px-4 py-5">
		<div class="row flex-lg-row-reverse align-items-center g-5 py-5">
		  <div class="col-6 col-sm-4 col-lg-4">
			<img src="<?= base_url() ?>/solar365/im_fd_vant.png" alt="Bootstrap Themes" width="156" height="350">
		  </div>
		  <div class="col-lg-6">
			<h1 class="display-5 fw-bold text-white lh-1 mb-3">DEIXE O SOL TRABALHAR PARA VOCÊ. GERANDO ENERGIA E ECONOMIA PARA SUA CASA!</h1>
			<p class="lead text-white">A Energia Solar já é uma realidade no Brasil e o Pará tem um enorme potencial
	na produção desse tipo de energia por ter dias ensolarados na maior
	parte do ano. Sistemas fotovoltaicos, geralmente instalados nos telhados das
	casas, que permitem a você produzir toda, ou uma parte da energia elétrica
	consumida em seu imóvel. Ficando livre dos aumentos anuais nas tarifas de energia.</p>
		  </div>
		</div>
	  </div>
	  </div>

  <div class="b-example-divider"></div>

  <div class="container px-4 py-5" id="icon-grid">
    <h2 class="pb-2 border-bottom fw-bold mb-0">Saiba quais são as vantagens de possuir um Sistema Solar, deixando de comprar energia cara e cheia de impostos passando a produzi-la de forma limpa e sustentável.</h2>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_1.png" width="100" height="100" alt=""/>
		<div>
          <h4 class="fw-bold mb-0"><p><strong>Redução de até 95%</strong> das
tarifas de energia</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_2.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Valorização</strong> do seu imóvel de até 30%</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_3.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Energia totalmente livre</strong> de impostos</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_4.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Instalação rápida</strong> e fácil</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_5.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Retorno do investimento</strong> garantido</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_6.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Manutenção simples</strong> e prática</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_7.png" width="100" height="100" alt=""/>
        <div>
          <h4 class="fw-bold mb-0"><p><strong>Vida útil</strong> e de longa durabilidade</p></h4>
        </div>
      </div>
      <div class="col d-flex align-items-start">
        <img src="<?= base_url() ?>/solar365/num_8.png" width="100" height="100" alt=""/>
        <div>
			<h4 class="fw-bold mb-0"><p><strong>Sistema</strong> Renovável</p></h4>
        </div>
      </div>
    </div>
  </div>
	
  <div class="b-example-divider"></div>

  <div class="container col-lg-4">
	  <br>
	<div class="row p-2 pb-0 pe-lg-0 pt-lg-2 align-items-center rounded-3 border shadow-lg">
		<div class="px-2 py-2 my-2 text-center">
			<a href="https://www.youtube.com/watch?v=U5pDV4aKgsI" role="button">
		  		<img src="<?= base_url() ?>/solar365/videoyoutube.png" width="558" height="315" alt=""/>
			</a>
		</div>
	</div>
	  <br>
  </div>
	
  <div class="b-example-divider mb-0"></div>
	
  <div class="px-4 pt-5 my-5 text-center">
    <h4 class="display-8 fw-bold">Adicione seus dados de consumo e simule o seu sistema.</h4>
	  <br>
    <div class="col-lg-6 mx-auto">
      <img src="<?= base_url() ?>/solar365/img_bt_simule-150x150.png" width="150" height="150" alt=""/>
		<div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
      </div>
		<a href="<?= base_url() ?>/home/orcamento" class="btn btn-primary btn-lg px-5 me-sm-6">SIMULE AQUI</a>
    </div>
    <div class="overflow-hidden" style="max-height: 30vh;">
      <div class="container px-5"></div>
    </div>
  </div>
	
  <div class="b-example-divider mb-0"></div>
	
 <div class="px-4 pt-5 my-5">
   	  <h1 class="display-8 fw-bold text-center">Saiba quais são as vantagens de possuir um Sistema Solar, deixando de comprar energia cara e cheia de impostos passando a produzi-la de forma limpa e sustentável.</h1>
			<div class="col-lg-4 mx-auto">		
				<ol>
					<li class="text-lbue">Simule o seu sistema solar</li>
					<li class="text-lbue">Elaborando a sua proposta</li>
					<li class="text-lbue">Negócio Fechado</li>
					<li class="text-lbue">Documentação de acesso à rede</li>
					<li class="text-lbue">Instalação do seu Sistema Solar</li>
					<li class="text-lbue">Ativação na distribuidora</li>
					<li class="text-lbue">Dinheiro no bolso</li>
				</ol>
			</div>
		<br>
		<div class="overflow-hidden text-center" style="max-height: 30vh;">
		  <div class="container px-5">
			<img src="<?= base_url() ?>/solar365/img_fundo_vantagens.png" width="600" height="170" alt="" sizes="(max-width: 600px) 100vw, 600px"/>
		  </div>
		</div>
  </div>
	
  <div class="b-example-divider mb-0"></div>
	
  <div class="px-2 pt-4 my-4 text-center">
	<h4 class="display-8 fw-bold">Seja Consciente, Seja Econômico, Seja Solar!</h4>
	<br>
	<div class="col-lg-6 mx-auto">
		<a href="<?= base_url() ?>/home/orcamento" class="btn btn-primary btn-lg px-5 me-sm-6">Saiba mais sobre energia solar</a>
	</div>
  </div>
	
  <div class="b-example-divider mb-0"></div>

  <div class="bg-dark text-secondary px-1 py-1 text-center">
    <div class="py-1">
      <div class="col-lg-6 mx-auto">
       <h2>Siga, comente e compartilhe:</h2>
        <h2>solar365</h2>
      </div>
    </div>
  </div>
</main>
    <script src="<?= base_url() ?>/assets/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>