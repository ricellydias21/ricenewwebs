<?= $this->extend('pastasolar/bpa/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/bpa/pagina') ?>
<?= $this->endSection() ?>