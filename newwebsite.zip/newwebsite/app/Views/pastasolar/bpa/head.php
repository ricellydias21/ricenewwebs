<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
	<title>BANPARÁ - Solar365</title>
	<link rel="canonical" href="<?= base_url() ?>/home/banpara/" />
	<meta property="og:locale" content="pt_BR" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="BANPARÁ - Solar365" />
	<meta property="og:description" content="O seu objetivo é economizar? Seja Solar365! Consciente de sua&hellip;  Leia mais" />
	<meta property="og:url" content="<?= base_url() ?>/home/banpara/" />
	<meta property="og:site_name" content="Solar365" />
	<meta property="og:image" content="<?= base_url() ?>/solar365/logo_banparaesolar365.png" />

    <link href="<?= base_url() ?>/assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
        }

        @media (min-width: 768px) {
        .bd-placeholder-img-lg {
        font-size: 3.5rem;
        }
        }
        .effects-layer {
        background-image: url("<?= base_url() ?>/solar365/img_topo_banpara.jpg");
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;
        }
        ol {
        counter-reset: my-awesome-counter;
        list-style: none;
        }
        ol li {
        counter-increment: my-awesome-counter;
        position: relative;
        }
        ol li::before {
        content: counter(my-awesome-counter);
        font-size: 1.5rem;
        font-weight: bold;
        position: absolute;
        --size: 32px;
        left: calc(-1 * var(--size) - 10px);
        line-height: var(--size);
        width: var(--size);
        height: var(--size);
        top: 0;
        text-align: center;
        border-style: solid;
        border-width: 1px 1px 1px 1px;
        border-color: #FF151F;
        border-radius: 400px 400px 400px 400px;
        }
        .text-lbue{
        color: #132A71;
        font-family: "Helvetica", Sans-serif;
        font-size: 32px;
        font-weight: 400;
        line-height: 1.2em;
        }
    </style>
  </head>
<body>
<?= $this->renderSection('content') ?>