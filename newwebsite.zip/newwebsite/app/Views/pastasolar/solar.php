<?= $this->extend('pastasolar/templates/head') ?>
<main>  
    <?= $this->section('content') ?>
        <?= $this->include('pastasolar/main/01') ?>
        <?= $this->include('pastasolar/main/02') ?>
        <?= $this->include('pastasolar/main/03') ?>
        <?= $this->include('pastasolar/main/04') ?>
        <?= $this->include('pastasolar/main/05') ?>
      </main>
    <?= $this->endSection() ?>