<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/1_oJSuqJ66scqnoEN9BlHEwA-72d71t8yiuc59xnd5a76wwer7fb0jvblzi.jpeg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">Energia Solar Valoriza o seu imóvel? - pastasolar</p>
            <p>Um sistema solar pode sim influenciar na valorização do seu imóvel em até 30%, confira: </p>
            <p>Nos últimos anos, o número de instalações de sistemas de energia solar cresceu de forma significativa, impulsionado pelo aumento nas tarifas de energia elétrica, pela quantidade de linhas de financiamento que ajudam no seu investimento e pela queda no custo total de um sistema fotovoltaico. </p>
            <p>Mas, além de ser uma energia limpa, que não agride o meio ambiente e um dos investimentos mais rentáveis atualmente, a energia solar também pode valorizar o seu imóvel. </p>
            <p><strong>Valorização do imóvel</strong> </p>
            <p>Para entender como um sistema solar valoriza o seu imóvel, pense o seguinte. Se você fosse comprar uma casa e tivesse que escolher entre um imóvel que depende da rede elétrica e está sujeita aos aumentos de tarifa, ou uma casa que gera a própria energia e economiza até 95% na conta, qual você escolheria? </p>
            <p>Provavelmente a 2º opção, correto? </p>
            <p>Uma pesquisa, patrocinada pelo Departamento de Energia dos Estados Unidos, mostrou que os americanos estão dispostos a pagar pelo menos 15 mil dólares a mais por uma casa que tenha um sistema próprio de geração de energia. </p>
            <p>Isso significa uma valorização de 3% a 6% no valor do imóvel e aqui no Brasil, a realidade é muito melhor, porque o nosso país tem um potencial de incidência solar enorme e uma fonte de energia que brilha por mais de 10 horas por dia e podia ser muito bem utilizada para ajudar a economizar dinheiro. </p>
            <p>Segundo dados do Ministério do Meio Ambiente, no Brasil os imóveis que geram energia limpa e soluções ecológicas, como a instalação de energia fotovoltaica, podem ter uma valorização no valor de 10% a 30%. </p>
            <p><strong>Valoriza meu negócio também?</strong> </p>
            <p>E o mesmo acontece caso você tenha uma empresa. O consumidor atual é extremamente engajado com causas sociais e ambientais e esse é um fator determinante na hora da tomada de decisão de compra. </p>
            <p>Por isso, além de valorizar o seu imóvel do seu negócio, empresas adeptas à energia solar ganham um Selo Solar, uma certificação criada em 2012 para destacar empresas que contribuem com a redução dos impactos ambientais. </p>
            <p>As empresas que possuem o Selo são reconhecidas por mostrar que apostam em uma energia limpa e renovável, além de se posicionarem como promotores da causa. </p>
            <p>Portanto, se você é empresário e quer valorizar ainda mais o seu negócio, ao investir em energia solar você contribui para a diminuição dos impactos ambientais e cria uma marca mais atrativa e competitiva no mercado. </p>
            <p>Por fim, a baixa manutenção e a economia na conta de luz no final do mês, aliadas à possibilidade de valorização e retorno de investimento, são só alguns dos motivos que comprovam que a energia solar é um dos melhores investimentos que você pode fazer pelo seu futuro. </p>
            <p>A mudança já está acontecendo e agora é o melhor momento para você aproveitar os benefícios de usar o sol como energia. Então, que tal solicitar um orçamento personalizado de um sistema fotovoltaico para o seu negócio ou sua casa? </p>
            <p>Você pode conferir quantas placas seriam necessárias para o seu consumo, além da economia mensal que você poderá obter com o sistema. </p>
            <p><strong><a href="https://pastasolar.com.br/simulador/">Solicite seu orçamento e Valorize Agora o Seu Imóvel </a></strong><br> </p>
            <p>Visite nossa <a href="https://www.facebook.com/Solar-365-104373134892691">página no Facebook. </a><br>Siga nosso <a href="https://www.instagram.com/solar.365/">Instagram </a></p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>