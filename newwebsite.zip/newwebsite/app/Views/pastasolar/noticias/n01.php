<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/falta-de-energia-72wxkxlpte7vqc6ryietom93uz6zn95m8e.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">Quando faltar energia elétrica, meu sistema solar continuará funcionando?</p>
            <p>Para facilitar, vamos começar pelo princípio de funcionamento do sistema de geração de energia solar. Quando há irradiação solar, o efeito fotovoltaico ocorre e tem-se a produção de energia elétrica através dos painéis solares. No entanto, a presença do sol ao longo do dia é inconstante, o que torna a geração de energia intermitente, variando muito ao longo de um dia. </p>
            <p>A variação quanto à geração de energia diária, cria a necessidade de utilização de um dispositivo para armazenar a carga produzida nos períodos de sol, permitindo ao consumidor utilizá-la em horários em que não há tanta irradiação, ou mesmo <a href="https://pastasolar.com.br/o-sistema-solar-funciona-a-noite/">durante à noite</a>. E é aí que surge a diferença mais significativa entre os dois tipos de sistemas fotovoltaicos.</p>
            <h2 id="então-quais-as-principais-diferenças-entre-os-sistemas-de-energia-solar-on-grid-e-off-grid"><a href="https://hccenergiasolar.com.br/posts/se-faltar-energia-eletrica-meu-sistema-solar-continuara-funcionando/#ent%C3%A3o-quais-as-principais-diferen%C3%A7as-entre-os-sistemas-de-energia-solar-on-grid-e-off-grid"></a>Principais diferenças entre os sistemas de energia solar on grid e off grid</h2><p>Nos sistemas off grid, a energia excedente gerada é armazenada em  baterias, que são dimensionadas para oferecer energia por um período sem irradiação determinado. Esses sistemas podem funcionar de maneira independente da rede da concessionária de energia elétrica.</p>
            <p>Já nos sistemas on grid, o armazenamento não é realizado em nenhum equipamento. A energia gerada durante os períodos com irradiação solar é consumida instantaneamente e o restante é injetado na rede da concessionária. Esse “crédito” gerado pela produção excedente é contabilizado, e será descontado do consumo de energia fornecida pela concessionária nos períodos em que não há sol. </p>
            <p>Essa diferenciação entre os tipos de sistemas embasa a explicação para o nosso questionamento central: quando faltar energia elétrica, o meu sistema solar continuará funcionando?</p>
            <p>Como nos sistemas off grid não há dependência da concessionária de energia, ou seja, o sistema funciona de maneira independente, você continuará tendo energia na sua casa ou empresa, gerada através do seu sistema fotovoltaico, mesmo quando não há sol.</p>
            <p>Já no sistema on grid, a dependência da rede da concessionária não permite o funcionamento isolado do sistema quando há falta de energia. Isso ocorre em virtude de resoluções da Aneel e dos módulos I e III do Prodist, que regulamentam as exigências de conexão do sistema de energia solar com a rede da concessionária.</p>
            <p>A tecnologia de armazenamento de energia está melhorando a cada dia. As possibilidades armazenamento de energia já estão sendo inseridas no mercado brasileiro, o que vem possibilitando uma autonomia maior da geração pelo consumidor. No entanto, o grande desafio desse tipo de sistema é a regulação pela Aneel e suas distribuidoras, que deverão, o quanto antes, adequar-se para permitir o funcionamento de maneira ilhada.</p>
            <p>E aí, compreendeu como tudo funciona? Se quer tirar mais dúvidas como esta antes de investir em sua usina solar, siga-nos nas nossas redes sociais e acompanhe outras explicações, curiosidades e dicas tão interessantes quanto esta. Nós estamos no <a href="https://www.facebook.com/Solar-365-104373134892691">Facebook</a>, no <a href="https://www.instagram.com/solar.365/">Instagram</a> e no <a href="https://www.youtube.com/channel/UCkWAsy0ZkMrNgkXnEoAPa-Q">YouTube!</a></p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>