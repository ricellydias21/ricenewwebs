<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/porque_investir_em_energia_solar-71yx3upqsqrlglguuwjbq9ljvk002zysya.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
        <p class="h1">Por Que Investir em Energia Solar Hoje? - pastasolar</p>
            <p class="has-black-color has-text-color">Mesmo com a queda das vendas durante os primeiros meses da pandemia, o mercado solar brasileiro apresenta forte retomada em 2020 e acaba de superar o total de conexões de 2019.</p>
            <p>Segundo os dados da Aneel (Agência Nacional de Energia Elétrica), que controla o segmento de Geração Distribuída (GD), o país já registra 126.219 novas conexões neste ano frente à 120.858 do ano passado. A liderança do segmento continua com os projetos de energia solar residencial, que respondem por mais de 72% dos novos sistemas conectados no período. Com o novo aumento da conta de luz previsto para os próximos cinco anos, mais desses consumidores agora buscam a tecnologia fotovoltaica para proteger o seu imóvel e reduzir o seu gasto com energia elétrica.</p>
            <p>A expansão do mercado fotovoltaico também ajuda na chamada retomada verde, promovendo uma fonte de geração elétrica 100% limpa ao mesmo tempo em que atrai investimentos e gera empregos no país.</p>
            <p>No total, o Brasil já possui mais de 305 mil telhados solares que somam uma potência instalada de 3,7 GW.</p>
            <p>Segundo levantamento da Associação Brasileira de Energia Solar Fotovoltaica (ABSOLAR,), isso representa mais de R$ 18,2 bilhões em investimentos acumulados e mais de 108 mil empregos criados desde 2012, ano de criação do segmento GD.</p>
            <p>“Agora, passada a fase mais aguda da atual pandemia, a energia solar fotovoltaica irá novamente alavancar a recuperação do Brasil. A solar será parte da solução, tanto para a nossa sociedade, quanto para o meio ambiente”, afirmou o CEO da ABSOLAR, Rodrigo Sauaia.</p>
            <p>Com um cenário favorável no Brasil, estima-se que a tecnologia mantenha a curva de crescimento em 2020 e seja um dos pilares da retomada econômica do país, assim como aconteceu nas crises econômicas de 2015 e 2016.</p>
            <p>Em seu último Plano Decenal de Energia, a EPE (Empresa de Pesquisa Energética), estima um total de até 3 milhões de consumidores com geração própria e 24,5 Gigawatts de potência solar distribuída no Brasil até 2030.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>