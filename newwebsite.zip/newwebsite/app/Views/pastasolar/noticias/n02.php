<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/shutterstock_587840948-72td899d2sni59xjjte4fptatjxni6rq2u.png);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">O Sistema Solar funciona à noite? - pastasolar</p>
            <p>Muitas pessoas têm dúvidas se energia solar funciona a noite. É importante ressaltar que esse tipo de sistema tem o pleno funcionamento em um dia de céu limpo, sem o surgimento de nuvens, independente da época do ano.</p>
            <p>A energia solar fotovoltaica não funciona à noite, porém existem duas soluções para isso: utilizar um banco de baterias que armazena a energia para ser usada quando não há geração ou ter o sistema conectado à rede distribuidora, que fornece energia à noite.</p>
            <p>Durante a noite, a geração de energia solar fotovoltaica não acontece, portanto, quando a única fonte de energia elétrica disponível é a fotovoltaica, é necessária a utilização de um banco de baterias conectado ao sistema para o armazenamento da energia. Quando o fornecimento de energia elétrica ocorre por parte da rede de distribuição pública, não é necessário conectar baterias ao sistema fotovoltaico, pois, nos dias chuvosos e durante a noite, a concessionária pode fornecer energia elétrica e suprir a necessidade do consumidor.</p>
            <p>Porém, o que acontece hoje, mesmo em um dia ensolarado – com o sistema solar fotovoltaico gerando energia elétrica – se o fornecimento de energia elétrica vinda da rede da distribuidora for interrompido, o sistema fotovoltaico também deixa de fornecer energia elétrica para o consumo. Essa decisão deu-se a partir da norma brasileira “ABNT NBR IEC 62116” que garante o “anti-ilhamento’ da unidade consumidora que possui instalado um sistema de geração distribuída com inversor interativo.</p>
            <p>Isso significa que um sistema não pode operar isolado (ilhado) do conjunto que o cerca (anti-ilhamento). Então, se todas as residências da rua ficarem sem energia elétrica, aquela que possui geração distribuída também deverá ficar.</p>
            <p>Uma das alternativas é o sistema fotovoltaico híbrido para trazer a junção dos pontos positivos dos sistemas conectados à rede (On Grid) e dos sistemas isolados (Off Grid). Dessa maneira, com as baterias de grande capacidade, o consumidor que possuir um sistema de geração distribuída com essas características ficará munido de três fontes de energia elétrica: a rede de distribuição, a geração fotovoltaica e o abastecimento por baterias.</p>
            <p>Essas opções dão ao consumidor mais um passo em busca da autossuficiência energética. Dessa forma, durante a noite ou em dias chuvosos, sem a ação dos raios solares, o sistema de geração será capaz de suprir o déficit do fornecimento de energia para algumas cargas, por meio das baterias.</p>
            <p>Além disso, o consumidor também pode escolher em quais períodos ele necessitará de energia elétrica originada da rede de distribuição, pela concessionária, evitando também o problema da falta de geração de energia elétrica por meio da energia solar durante o período noturno.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>