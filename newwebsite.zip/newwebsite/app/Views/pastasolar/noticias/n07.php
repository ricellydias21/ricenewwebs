<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/modulo_fotovotaico_1000x600-71r0k06xzlll5hkbo3zpyly1jit54u3uyq.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
        <p class="h1">Módulo Fotovoltaico - pastasolar</p>
          <p>O módulo fotovoltaico é a unidade básica de todo o sistema. O módulo é composto por células conectadas em arranjos produzindo tensão e corrente suficientes para a utilização da energia. É indispensável o agrupamento em módulos já que uma célula fornece pouca energia elétrica, em uma tensão em torno de 0,4 Volts no ponto de máxima potência, conforme explicado</p>
          <p>na seção 4.1.3. A densidade de corrente é da ordem de 30 mA/cm2 . Adicionalmente a célula apresenta espessura muito reduzida, necessitando de proteção contra esforços mecânicos e fatores ambientais. O número de células conectadas em um módulo e seu arranjo, que pode ser série e/ou paralelo, depende da tensão de utilização e da corrente elétrica desejada. Deve ser dada cuidadosa atenção às células a serem reunidas, devido às suas características elétricas. A incompatibilidade destas características leva a módulos “ruins”, porque as células de maior fotocorrente e fotovoltagem dissipam seu excesso de potência nas células de desempenho inferior. Em conseqüência, a eficiência global do módulo fotovoltaico é reduzida.</p>
          <p>Célula Fotovoltaica</p>
          <p>A conversão da energia solar em energia elétrica é obtida utilizando-se material semicondutor como elemento transformador, conhecido como célula fotovoltaica ou célula solar.</p>
          <p>. Os semicondutores mais apropriados à conversão da luz solar são os mais sensíveis, ou melhor, aqueles que geram o maior produto corrente-tensão para a luz visível, já que a maior parcela de energia fornecida pelos raios do sol está dentro da faixa visível do espectro. 44 Manual de Engenharia para Sistemas Fotovoltaicos Existe todo um processo para que o material semicondutor se transforme realmente em uma célula fotovoltaica. O que ocorre, de uma maneira geral, é que o semicondutor deve passar por uma etapa de purificação e, em seguida, por uma etapa de dopagem, através da introdução de impurezas, dosadas na quantidade certa.</p>
          <p>Os principais tipos de células fotovoltaicas são:</p>
          <p>Silício (Si) Monocristalino Este material é basicamente o mesmo utilizado na fabricação de circuitos integrados para microeletrônica. As células são formadas em fatias de um único grande cristal, previamente crescido e enfatiado. A grande experiência na sua fabricação e pureza do material, garantem alta confiabilidade do produto e altas eficiências. Enquanto o limite teórico de conversão da luz solar em energia elétrica, para esta tecnologia é de 27%, valores nas faixas de 12 a 16% são encontrados em produtos comerciais. Devido às quantidades de material utilizado e à energia envolvida na sua fabricação, esta tecnologia apresenta sérias barreiras para redução de custos, mesmo em grandes escalas de produção.</p>
          <p>Silício (Si) Multicristalino Também chamado de Silício (Si) Policristalino; estas células são fabricadas a partir do mesmo material que, ao invés de formar um único grande cristal, é solidificado em forma de um bloco composto de muitos pequenos cristais. A partir deste bloco são obtidas</p>
          <p>fatias e fabricadas as células. A presença de interfaces entre os vários cristais reduz um pouco a eficiência destas células. Na prática os produtos disponíveis alcançam eficiências muito próximas das oferecidas em células monocristalinas. Neste caso, a quantidade de material por célula é basicamente o mesmo do caso anterior, entretanto, a energia necessária para produzí-las é significativamente reduzida.</p>
          <p>Filmes Finos</p>
          <p>No intuito de buscar formas alternativas de se fabricar células fotovoltaicas, muito trabalho de pesquisa tem sido realizado. Um dos principais campos de investigação é o de células de filmes finos. O objetivo geral é obter uma técnica através da qual seja possível produzir células fotovoltaicas confiáveis, utilizando pouco material semicondutor, obtido de forma passível de produção em larga escala, resultando em custo mais baixo do produto e consequentemente da energia gerada. Estes estudos tem-se dirigido a diferentes materiais semicondutores e técnicas de deposição destes em camadas finas com espessura de poucos mícrons. Entre os materiais mais estudados estão o silício amorfo hidrogenado (a-Si:H), o disseleneto de cobre e índio (CIS) e o telureto de cádmio (CdTe).</p>
          <p>O silício amorfo é responsável pelo maior volume de produtos nesta área embora outros já sejam disponíveis. Não é claro hoje qual das tecnologias em estudo terá maior sucesso no futuro. O que se pode dizer é que todas têm potencialidade de gerar produtos de baixo custo se produzidos em grande escala. Por outro lado, todas têm ainda obstáculos a serem vencidos antes que possam alcançar uma plena maturidade industrial e atingir o nível de confiança das células cristalinas. Para o silício amorfo, estes obstáculos estão relacionados principalmente com a estabilidade do material, efeito Staebler-Wronski. No entanto, este efeito tem sido minimizado através da adoção de células com múltiplas camadas. Manual de Engenharia para Sistemas Fotovoltaicos 45 Células com concentração</p>
          <p>Uma possibilidade alternativa é o uso de lentes concentradoras acopladas a células de alta eficiência. Para este uso o próprio silício cristalino e o arseneto de gálio (GaAs) têm sido utilizados na fabricação destas células. A questão aqui é como conseguir sistemas simples e eficientes de focalização de luz e de seguimento do Sol, uma vez que apenas os raios diretos do Sol podem ser concentrados sobre o dispositivo.</p>
          <p>Inversor</p>
          <p>O inversor solar é o equipamento usado para converter a energia gerada pelos painéis solares de corrente contínua (CC) em corrente alternada (CA). O inversor solar é fundamental para que você possa usar a energia fotovoltaica para alimentar os utensílios elétricos usados no dia a dia.</p>
          <p>Nos sistemas conectados, os inversores solares sincronizam o equipamento com a rede da concessionária.</p>
          <p>O inversor solar estabelece a ligação entre o gerador fotovoltaico e a rede AC ou a carga AC. A sua principal tarefa consiste em converter o sinal eléctrico DC do gerador fotovoltaico num sinal eléctrico AC, e ajustá-lo para a frequência e o nível de tensão da rede a que está ligado.</p>
          <p>Também é conhecido como conversor DC/AC. Com a utilização dos modernos dispositivos electrónicos, a conversão num sinal de corrente alternada standard envolve perdas relativamente pequenas.</p>
          <p>Dependendo da aplicação, existe uma distinção entre os inversores utilizados nos sistemas com ligação à rede (inversores de rede) e nos sistemas autónomos (inversores autónomos).</p>
          <p>Nos sistemas fotovoltaicos com ligação à rede, o inversor é ligado à rede eléctrica principal de forma directa ou através da instalação do serviço eléctrico do prédio. Com uma ligação directa, a electricidade produzida é injectada directamente na rede eléctrica pública. Com o acoplamento à instalação do prédio, a energia gerada é em primeiro lugar consumida no prédio, sendo então a excedente fornecido à rede pública.</p>
          <p>sistema de fixação das placas solares</p>
          <p>Essa é uma parte muito importante de um sistema fotovoltaico. Afinal de contas, imagina só a dor de cabeça em ver seus painéis solares voando quando acontecer uma ventania ou tempestade. É justamente isso que você pode ter que lidar se o seu fornecedor não oferecer um suporte para fixação das placas solares de qualidade. Além do mais, também é preciso estar atento à instalação correta.</p>
          <p>Cabos, conectores e outros materiais elétricos padrões</p>
          <p>Essas peças fazem a condução da corrente elétrica entre os painéis solares e os inversores. Para que tudo saia como planejado, é preciso dimensionar de modo certo o sistema. Assim, evitam-se riscos e danos à instalação.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>