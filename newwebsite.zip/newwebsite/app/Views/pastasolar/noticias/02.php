<nav class="container-fluid nav nav-underline solar365-Center background-overlay2" style="background-image: url(../solar365/img_top_blog.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>