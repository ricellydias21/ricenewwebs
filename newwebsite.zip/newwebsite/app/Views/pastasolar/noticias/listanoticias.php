<div class="album py-5 bg-light">
    <div class="container">
		<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                  <br>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/falta-de-energia-72wxkxlpte7vqc6ryietom93uz6zn95m8e.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/quando-faltar-energia-eletrica-meu-sistema-solar-continuara-funcionando/" class="nav-link px-2 text-secondary">Quando faltar energia elétrica, meu sistema solar continuará funcionando?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Para facilitar, vamos começar pelo princípio de funcionamento do sistema…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/energia_solar_durante_inverno-729p5vg83fuzw9j242on17v8uqhomzybcq.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/e-possivel-gerar-enegia-solar-no-inverno/" class="nav-link px-2 text-secondary">É POSSÍVEL GERAR ENEGIA SOLAR NO INVERNO?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Uma das maiores dúvidas sobre o funcionamento da tecnologia fotovoltaica…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/porque_investir_em_energia_solar-71yx3upqsqrlglguuwjbq9ljvk002zysya.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/por-que-investir-em-energia-solar-hoje/" class="nav-link px-2 text-secondary">Por Que Investir em Energia Solar Hoje?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Mesmo com a queda das vendas durante os primeiros meses…</p>
                        </div>
                     </div>
                  </div>
			<div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/unnamed-1-72td4lzz12hvdbxw0t88rhuozpqmiu22va.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/e-possivel-gerar-minha-conta-de-energia-com-energia-solar/" class="nav-link px-2 text-secondary">Quando faltar energia elétrica, meu sistema solar continuará funcionando?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Infelizmente, não! Por mais que o gerador solar supra seu…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/usina_solar_1000x600-71r0gmqrjb7sl5r1ly0tqw181anihaf0ci.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/usina-solar/" class="nav-link px-2 text-secondary">Usina Solar</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Quando falamos de energia solar fotovoltaica no Brasil, usina solar…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/energia_solar_nobrasil_1000x600-71r0ewfebkzav5z7j3rhmassky4wk53wqq.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/energia-solar-brasil/" class="nav-link px-2 text-secondary">Energia Solar No Brasil</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Atualmente, o Brasil utiliza a energia solar fotovoltaica em residências,…</p>
                        </div>
                     </div>
                  </div>
			<div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/modulo_fotovotaico_1000x600-71r0k06xzlll5hkbo3zpyly1jit54u3uyq.jpg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/modulo-fotovoltaico/" class="nav-link px-2 text-secondary">Módulo Fotovoltaico</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">O módulo fotovoltaico é a unidade básica de todo o…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/shutterstock_587840948-72td899d2sni59xjjte4fptatjxni6rq2u.png" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							    <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/o-sistema-solar-funciona-a-noite/" class="nav-link px-2 text-secondary">O Sistema Solar funciona à noite?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Muitas pessoas têm dúvidas se energia solar funciona a noite.…</p>
                        </div>
                     </div>
                  </div>
                  <div class="col">
                     <div class="card shadow-sm">
                        <img src="<?= base_url() ?>/solar365/1_oJSuqJ66scqnoEN9BlHEwA-72d71t8yiuc59xnd5a76wwer7fb0jvblzi.jpeg" width="100%" height="100%" alt="">
                        <div class="card-body">
                           <h5 class="card-title">
							   <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          							<li>
										<a href="<?= base_url() ?>/noticias/energia-solar-valoriza-o-seu-imovel/" class="nav-link px-2 text-secondary">Energia Solar Valoriza o seu imóvel?</a>
									</li>
        						</ul>
							</h5>
                           <p class="card-text">Um sistema solar pode sim influenciar na valorização do seu…</p>
                        </div>
                     </div>
                  </div>
			
       </div>
    </div>
  </div>