<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/img_top_blog.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">Energia Solar No Brasil - pastasolar</p>
            <p>Atualmente, o Brasil utiliza a energia solar fotovoltaica em residências, comércios, agronegócios e indústrias, assim como por meio de grandes usinas de energia solar.</p>
            <p>Por conta das enormes vantagens para a maioria dos consumidores de energia elétrica no Brasil, principalmente os residenciais, a tecnologia fotovoltaica cresce a passos largos em nosso país.</p>
            <p>Mais importante, porém, do que o número absoluto, é a tendência clara de um crescimento acelerado da energia solar no Brasil.</p>
            <p>Se a projeção da ANEEL se concretizar, logo em 2020 o Brasil terá cerca de 174 mil sistemas fotovoltaicos instalados, representando cerca de 0,21% do total de unidades consumidoras brasileiras passíveis de se adquirir sistemas em geração distribuída. Já em 2024, a projeção é de 886.700 sistemas fotovoltaicos.</p>
            <p>Do mesmo modo ao que temos hoje, a maioria dos sistemas serão instalados em unidades residenciais, cerca de 91% do total nacional contra somente 9% de sistemas comerciais em números absolutos.</p>
            <p>Uma curiosidade sobre a energia solar é que, se levarmos em consideração a mesma projeção, mas agora em potência em MW, o cenário passa a ser diferente.</p>
            <p>É possível perceber que a distribuição passa a ser mais equilibrada entre os três grandes grupos, residencial, comercial e outros.</p>
            <p>Isso significa que, os sistemas comerciais permanecerão em menor quantidade, mas o tamanho médio do sistema é superior ao residencial e ao comercial.</p>
            <p>Os sistemas comerciais nesse caso ficam com cerca de 24% do total da potência instalada, e serão responsáveis por cerca de 784 MW de um total de 3,2 GW.</p>
            <p>Por isso, mesmo que a tecnologia tenha partido de algumas dezenas de sistemas fotovoltaicos em 2013 para milhares até agora, o setor de energia solar no Brasil, como um todo, tem mantido um passo de crescimento acima de 300% ao ano, desde 2014, e isso abre enormes possibilidades de geração de emprego, renda, criação de novas empresas e negócios, a fim de sustentar essa possibilidade de crescimento contínuo.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>