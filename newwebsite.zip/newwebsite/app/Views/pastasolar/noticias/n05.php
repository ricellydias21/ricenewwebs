<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/energia_solar_durante_inverno-729p5vg83fuzw9j242on17v8uqhomzybcq.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">É POSSÍVEL GERAR ENEGIA SOLAR NO INVERNO? - pastasolar</p>
            <p>Uma das maiores dúvidas sobre o funcionamento da tecnologia fotovoltaica é se os sistemas produzem energia durante o inverno.<br>Embora os efeitos dessa estação não sejam tão impactantes na região Norte, aproveitamos essa época de dias chuvosos para desmistificar de vez essa falsa concepção popular sobre a tecnologia fotovoltaica.<br>Diferença Entre Tecnologias<br>A primeira coisa que se deve ter em mente quando falamos de energia solar é a diferença entre as duas principais tecnologias que utilizam essa fonte geradora, que são a energia solar térmica e energia solar fotovoltaica.<br>Enquanto a primeira utiliza o calor do sol para aquecer a água e outros fluídos, o qual é captado através de placas coletoras instaladas nos telhados, a solar fotovoltaica é aquela em que a luz do sol é captada por placas solares (chamados de módulos fotovoltaicos) e transformada em energia elétrica através do efeito fotovoltaico.<br>Portanto, os dias mais nublados do inverno amazônico não influenciam negativamente na geração de energia do sistema, ao contrário, eles são até benéfico para o desempenho dos painéis, os quais, assim como a maioria dos equipamentos eletrônicos, funcionam de forma mais eficiente em temperaturas mais amenas.<br>Cada módulo tem suas especificações e o impacto do calor sobre a sua potência é um dos aspectos que definem a qualidade do mesmo.<br>Na folha de dados do módulo, disponibilizada pelo fabricante, encontramos os coeficientes de temperatura, que indicam a porcentagem de perda da eficiência para cada grau acima dos 25º utilizado nos testes feitos em laboratórios.<br>Se existe uma perda de geração elétrica pelo sistema no inverno, essa se dá por conta da duração dos dias, que são mais curtos, e da angulação do sol em relação à Terra, que faz com que a sua luz chegue de maneira mais amena a superfície terrestre durante a estação.</p>
            <p>Todavia, todos esses fatores são devidamente analisados e compensados pela nossa equipe técnica na hora do dimensionamento do sistema.</p>
            <p><strong>Sistema de energia solar: economia no inverno</strong><br>Agora que ficou claro que os sistemas solares fotovoltaicos funcionam, muito bem, no inverno, podemos falar da outra vantagem que é ter um desses instalado em sua casa nessa época de dias mais chuvosos.<br>Como sabemos, a energia elétrica gerada por um sistema pode abastecer todos os equipamentos elétricos de uma casa e suprir todo o seu consumo energético, bastando apenas que seja feito o correto dimensionamento do mesmo.<br>E é nesse cenário que um sistema fotovoltaico pode trazer grande economia para o consumidor, provendo toda essa energia de forma limpa e permitindo que o consumidor reduza em até 95% da sua conta de luz.<br>E você, já pensou em poder contar com uma economia dessas em todas as épocas do ano? Acesse o nosso <a href="https://pastasolar.com.br/simulador/" target="_blank" rel="noreferrer noopener">simulador</a> e saiba o quanto pode economizar com energia solar.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>