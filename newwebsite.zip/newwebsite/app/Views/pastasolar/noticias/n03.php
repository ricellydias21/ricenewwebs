<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/unnamed-1-72td4lzz12hvdbxw0t88rhuozpqmiu22va.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">É possível gerar minha conta de energia com Energia Solar? - pastasolar</p>
            <p>Infelizmente, não! Por mais que o gerador solar supra seu consumo, até mesmo gere crédito junto à concessionária, existem taxas referentes ao transporte de energia. Essas taxas são chamadas de “Custo de Disponibilidade” – ou Taxa de Consumo Mínimo.</p>
            <h2>O QUE É CUSTO DE DISPONIBILIDADE?</h2><p>O Custo de Disponibilidade é uma taxa cobrada pelas concessionárias para cobrir os gastos com manutenção da rede de distribuição de energia elétrica. Sendo cobrada independentemente da quantidade de energia elétrica consumida no período.</p>
            <p>A  ANEEL (Agência Nacional de Energia Elétrica), através da resolução <a href="http://www2.aneel.gov.br/cedoc/bren2010414.pdf">414/2010</a>, determina que as Taxas de Consumo Mínimo serão atribuídas de acordo com o padrão da rede de conexão com a rede elétrica. Seguindo estes valores para o cálculo da cobrança mínima:</p>
            <p>• <em>Rede monofásica</em>: valor em moeda corrente equivalente a 30 kWh</p>
            <p>• <em>Rede bifásica</em>: valor em moeda corrente equivalente a 50 kWh</p>
            <p>• <em>Rede trifásica</em>: valor em moeda corrente equivalente a 100 kWh</p>
            <p>Desta forma, caso o consumo de energia seja inferior ao mínimo estabelecido, o usuário será cobrado pelo Custo de Disponibilidade. Tal valor é a taxa mínima de energia multiplicada pela tarifa da concessionária, que varia de acordo com a região.</p>
            <h2>SENDO ASSIM, O SISTEMA DE ENERGIA SOLAR AINDA É UM BOM INVESTIMENTO?</h2><p>Sim! Apesar de não ser possível zerar completamente a conta de luz, a energia gerada é bastante significativa, o que torna a instalação de um sistema fotovoltaico residencial um ótimo investimento.</p>
            <p>Quer saber o quanto você pode economizar em sua conta de energia investindo em um Sistema Solar?</p>
            <p><a href="https://pastasolar.com.br/simulador/">Faça um orçamento!</a></p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>