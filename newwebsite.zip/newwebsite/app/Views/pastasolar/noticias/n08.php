<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<nav class="container-fluid nav nav-underline pastasolar-Center background-overlay2" style="background-image: url(<?= base_url() ?>/pastasolar/usina_solar_1000x600-71r0gmqrjb7sl5r1ly0tqw181anihaf0ci.jpg);" aria-label="Secondary navigation">
   <section class="min-vh-100 text-center container">
      <div class="row py-lg-5">
         <div class="col-lg-5 col-md-8 mx-auto">
            <h2 class="a13ree-written-headline" data-speed="82" data-loop="0">
               <span class="written-lines">Notícias<br></span>
            </h2>
         </div>
      </div>
   </section>
</nav>
<main>
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <p class="lead text-muted">
          <p class="h1">Usina Solar - pastasolar</p>
            <p>Quando falamos de energia solar fotovoltaica no Brasil, usina solar é logo um dos tópicos quem vem a nossa mente, visto a quantidade desses projetos sendo instalados no país.</p>
            <p>Diferentemente do segmento de geração distribuída, que cresce rapidamente no Brasil através dos sistemas fotovoltaicos instalados diretamente nas casas e empresas dos consumidores, na usina solar a energia é gerada de forma centralizada e em grande quantidade.</p>
            <p>Devido a disponibilidade de luz do sol existente no país, esse segmento de geração centralizada também vem avançando a passos largos, com novas instalações de usinas de energia solar no Brasil a cada ano.</p>
            <p>No Brasil, onde o potencial da energia solar fotovoltaica é imenso, não utilizar essa fonte limpa e renovável para suprir a demanda da população seria algo sem sentido e exatamente por isso que o governo vem investindo em usinas de energia solar no Brasil como forma de diversificar a nossa matriz energética.</p>
            <p>As usinas solares fotovoltaicas operam de forma semelhante ao funcionamento dos sistemas de energia solar fotovoltaica residencial, porém em uma escala bem maior, pois são projetadas para a produção e venda de grande volume de energia em alta tensão.</p>
            <p>Nessas usinas fotovoltaicas, que são o único tipo de usina sendo instalado de forma comercial no Brasil (existem também as usinas solares Heliotérmicas), milhares, senão milhões, de painéis fotovoltaicos captam a luz do sol e a convertem em energia elétrica através de um processo chamado efeito fotovoltaico.</p>
            <p>Os painéis são montados no solo, podendo ser fixados em terra ou então sobre estruturas chamadas de Solar-Tracker ou Rastreador Solar, que são</p>
            <p>dispositivos que direcionam o painel conforme a posição do sol, de forma a deixá-lo sempre no melhor ângulo para captação da luz.</p>
            <p>Embora isso aumente consideravelmente a eficiência de geração do módulo, esses dispositivos também encarecem o custo final da usina.</p>
            <p>Essa energia, que é gerada em Corrente Contínua (CC), é então enviada aos inversores fotovoltaicos, que a convertem em Corrente Alternada (CA), que é o tipo de energia que consumimos em nossos estabelecimentos.</p>
            <p>Até esse ponto não existe diferença para os sistemas de energia solar residencial, no entanto, como essa energia será enviada aos pontos de consumo através das linhas de alta tensão, ela precisa passar antes pelos transformadores, que irão elevar sua tensão de 380 volts para 13.800 volts ou até 230.000 volts.</p>
            <p>Atualmente existem 73 usinas solares em operação no Brasil somando uma potência de geração de pouco mais de 2 gigawatt, segundo a Associação Brasileira de Energia Solar Fotovoltaica (ABSOLAR)</p>
            <p>Com esse montante, a fonte recentemente superou a energia nuclear como a 7ª fonte de maior potência na matriz elétrica brasileira.</p>
            <p>Esse cenário relativamente escasso de usinas de energia solar no Brasil, no entanto, está com os dias contados.</p>
            <p>De acordo com o banco de dados da ANEEL, existem mais 22 usinas solares já em construção no país, e adicionais 37 projetos já contratados, porém que ainda não saíram do papel.</p>
            <p>Investimentos como esse já são esperados no Brasil e devem ser cada vez mais frequentes.</p>
            <p>Conforme projetado pela ABSOLAR no ano passado, para o Brasil alcançar suas metas de redução de emissão assumidas no Acordo de Paris, R$125 milhões devem ser investidos em projetos de energia Solar até 2030.</p>
          </p>
        </div>
    </div>
 </section>
</main>
<?= $this->endSection() ?>