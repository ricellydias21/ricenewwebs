<div class="bg-dark text-secondary px-4 py-5 text-center">
         <div class="py-5">
            <div class="row align-items-md-stretch">
               <div class="col-md-6">
                  <div class="h-100 p-5 text-white bg-dark rounded-3">
                     <p>DIGA OLÁ! NÓS GOSTAMOS DISSO!</p>
                     <h2>ENTRAR EM CONTATO</h2>
                     <div class="elementor-element-6e3190b">
                     </div>
                     <p>Estamos aguardando uma mensagem sua!</p>
                     <p>Tv. Benjamim Constant, 1122</p>
                     <p>atendimento@baparsolar.com</p>
                     <p>(91) 3115 0365</p>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="h-100 p-5 bg-light border rounded-3">
                     <iframe loading="lazy" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7977.073949933868!2d-48.489497!3d-1.452131!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x92a48e901b0c398d%3A0x2348a4b077c54144!2sTv.%20Benjamin%20Constant%2C%201122%20-%20Nazar%C3%A9%2C%20Bel%C3%A9m%20-%20PA%2C%2066035-060!5e0!3m2!1spt-BR!2sbr!4v1607347937328!5m2!1spt-BR!2sbr" width="600" height="430" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                  </div>
               </div>
            </div>
         </div>
         <h2 class="pb-1 border-bottom"></h2>
         <div class="py-5">
            <div class="col-lg-6 mx-auto">
               <div class="container px-4 py-5" id="icon-grid">
                  <h2 class="pb-2 border-bottom"><img src="../solar365/icon_solar365_120x69.png" width="120" height="69" alt=""/></h2>
                  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
                     <div class="col-lg-4 d-flex align-items-start">
                        <div>
                           <h4 class="fw-bold mb-2">Porque a solar365</h4>
                           <p>Estamos num momento de futuras transformações no mundo, e a Solar365 veio para inovar no processo sistemático da tecnologia solar com seu DNA inovador e tecnológico.</p>
                        </div>
                     </div>
                     <div class="col-lg-4 d-flex align-items-start">
                        <div>
                           <h4 class="fw-bold mb-0">Contatos</h4>
                           <dl>
                              <dd>+55 (91) 3115 0365</dd>
                              <dd>atendimento@baparsolar.com</dd>
                              <dd>Seg. - Sex. 8h - 18h</dd>
                           </dl>
                        </div>
                     </div>
                     <div class="col-lg-4 d-flex align-items-start">
                        <div>
                           <h4 class="fw-bold mb-0">Posts Recentes</h4>
                           <dl>
                              <dd>Quando faltar energia elétrica, meu sistema solar continuará funcionando?</dd>
								<p>1 de março de 2021
								O Sistema Solar funciona à noite?
								22 de fevereiro de 2021
								É possível gerar minha conta de energia com Energia Solar?
								22 de fevereiro de 2021</p>
                        </dl>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>