<?= $this->extend('pastasolar/templates/head') ?>
<?= $this->section('content') ?>
<?= $this->include('pastasolar/main/01') ?>
<?= $this->include('pastasolar/noticias/02') ?>
<?= $this->endSection() ?>